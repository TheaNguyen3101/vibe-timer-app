export const metadata = {
  title: "Vibe Timer",
  description: "Productivity timer with daily goals, notes, and vibes",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
