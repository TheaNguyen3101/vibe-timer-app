'use client';

import { useEffect, useMemo, useState } from 'react';
import Goals from '../components/Goals';
import Timer from '../components/Timer';
import VibePanel from '../components/VibePanel';
import { loadData, saveData, todayKey } from '../lib/storage';
import NotesModal from '../components/NotesModal';

export default function HomePage() {
  const [data, setData] = useState(loadData());
  const [noteOpen, setNoteOpen] = useState(false);
  const [lastEndedMode, setLastEndedMode] = useState(null);

  useEffect(()=>{
    saveData(data);
  }, [data]);

  const addGoal = (text) => setData(d => ({ ...d, goals: [...d.goals, text] }));
  const removeGoal = (idx) => setData(d => ({ ...d, goals: d.goals.filter((_, i)=>i!==idx) }));

  const onSessionEnd = (mode) => {
    // record session
    setData(d => ({ ...d, sessions: [...d.sessions, { mode, endedAt: Date.now() }] }));
    if (mode === 'focus') {
      setLastEndedMode(mode);
      setNoteOpen(true);
    }
  };

  const onSaveNote = (text) => {
    setData(d => ({ ...d, notes: [...d.notes, { text, at: Date.now() }] }));
    setNoteOpen(false);
  };

  const endDay = () => {
    window.location.href = '/summary';
  };

  const bgClass = useMemo(()=>{
    const style = data?.vibe?.style || 'from-slate-50 via-sky-50 to-slate-100';
    return `bg-gradient-to-br ${style}`;
  }, [data?.vibe]);

  return (
    <div className={bgClass + " min-h-screen"}>
      <div className="min-h-screen bg-black/10">
        <div className="max-w-6xl mx-auto p-4 sm:p-6">
          <header className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Vibe Timer</h1>
            <div className="text-sm text-slate-700">Date: {todayKey()}</div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-1 bg-white/60 rounded-2xl p-4 shadow">
              <Goals goals={data.goals} addGoal={addGoal} removeGoal={removeGoal} />
            </div>
            <div className="md:col-span-1 bg-white/60 rounded-2xl p-4 shadow">
              <Timer onSessionEnd={onSessionEnd} sessions={data.sessions} />
              <div className="mt-4">
                <button className="w-full px-3 py-2 rounded-lg border" onClick={()=>setNoteOpen(true)}>Add Note Manually</button>
              </div>
            </div>
            <div className="md:col-span-1 bg-white/60 rounded-2xl p-4 shadow">
              <VibePanel vibe={data.vibe} setVibe={(v)=>setData(d => ({ ...d, vibe: v }))} />
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <button className="px-4 py-2 rounded-lg bg-slate-900 text-white" onClick={endDay}>End Work Day →</button>
          </div>
        </div>
      </div>

      <NotesModal open={noteOpen} onClose={()=>setNoteOpen(false)} onSave={onSaveNote} />
    </div>
  );
}
