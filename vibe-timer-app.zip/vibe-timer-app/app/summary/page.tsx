'use client';

import { useEffect, useState } from 'react';
import { loadData, todayKey } from '../../lib/storage';

export default function SummaryPage() {
  const [data, setData] = useState({ goals: [], notes: [], vibe: {} });

  useEffect(()=>{
    setData(loadData());
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-slate-100">
      <div className="max-w-5xl mx-auto p-4 sm:p-6">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">End of Day Summary</h1>
          <div className="text-sm text-slate-700">Date: {todayKey()}</div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white/70 rounded-2xl p-4 shadow">
            <h2 className="text-xl font-semibold mb-3">Goals</h2>
            <ul className="list-disc pl-5 space-y-1">
              {data.goals?.map((g, i)=>(<li key={i}>{g}</li>))}
            </ul>
          </div>
          <div className="bg-white/70 rounded-2xl p-4 shadow">
            <h2 className="text-xl font-semibold mb-3">Achievements (Notes)</h2>
            <ul className="list-disc pl-5 space-y-1">
              {data.notes?.map((n, i)=>(<li key={i}>{n.text}</li>))}
            </ul>
          </div>
        </div>

        <div className="mt-6 flex gap-2">
          <a href="/" className="px-3 py-2 rounded-lg border">← Back</a>
        </div>
      </div>
    </div>
  );
}
