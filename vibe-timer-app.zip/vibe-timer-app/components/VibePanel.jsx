'use client';
import { useState, useEffect } from 'react';
import { startAmbient, stopAmbient } from '../lib/audio';

const presets = [
  { label: 'Cozy Coffee Shop', prompt: 'cozy warm coffee shop', gradient: 'from-amber-100 via-rose-100 to-amber-200' },
  { label: 'Zen Garden', prompt: 'zen garden', gradient: 'from-green-100 via-emerald-100 to-lime-200' },
  { label: 'Rainy Study', prompt: 'rain on window', gradient: 'from-slate-100 via-blue-100 to-slate-200' },
  { label: 'Neon City', prompt: 'futuristic neon city', gradient: 'from-fuchsia-100 via-purple-100 to-violet-200' },
];

export default function VibePanel({ vibe, setVibe }) {
  const [input, setInput] = useState(vibe?.prompt || '');
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.08);

  useEffect(()=>{
    return ()=>{ stopAmbient(); };
  }, []);

  const applyPreset = (p) => {
    setVibe({ prompt: p.prompt, style: p.gradient });
  };

  const applyVibe = () => {
    // For now, map input to closest preset gradient; AI hookup can be added later.
    const match = presets.find(p => input.toLowerCase().includes(p.prompt.split(' ')[0]));
    const gradient = match ? match.gradient : 'from-slate-50 via-sky-50 to-slate-100';
    setVibe({ prompt: input || 'custom', style: gradient });
  };

  const toggleAudio = () => {
    if (!playing) {
      startAmbient((vibe?.prompt || 'cozy'), volume);
      setPlaying(true);
    } else {
      stopAmbient();
      setPlaying(false);
    }
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Set Your Vibe</h2>
      <div className="flex gap-2">
        <input
          className="flex-1 border rounded-lg p-2"
          placeholder='e.g., "cozy warm coffee shop"'
          value={input}
          onChange={(e)=>setInput(e.target.value)}
        />
        <button className="px-3 py-2 rounded-lg bg-slate-900 text-white" onClick={applyVibe}>
          Apply
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {presets.map(p=>(
          <button key={p.label} className="px-3 py-2 rounded-lg border" onClick={()=>applyPreset(p)}>{p.label}</button>
        ))}
      </div>
      <div className="flex items-center gap-3 pt-2">
        <button className="px-3 py-2 rounded-lg border" onClick={toggleAudio}>
          {playing ? 'Stop Ambient' : 'Play Ambient'}
        </button>
        <label className="text-sm">Volume
          <input
            type="range"
            min="0"
            max="0.2"
            step="0.01"
            value={volume}
            onChange={(e)=>setVolume(parseFloat(e.target.value))}
            className="ml-2 align-middle"
          />
        </label>
      </div>
      <p className="text-xs text-slate-600">Note: AI image/audio generation can be added later. This uses gradients and generated ambient noise.</p>
    </div>
  );
}
