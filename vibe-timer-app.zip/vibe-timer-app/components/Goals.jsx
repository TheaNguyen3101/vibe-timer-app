'use client';
import { useState } from 'react';

export default function Goals({ goals, addGoal, removeGoal }) {
  const [text, setText] = useState('');
  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Today’s Goals</h2>
      <div className="flex gap-2">
        <input
          className="flex-1 border rounded-lg p-2"
          placeholder="Add a goal…"
          value={text}
          onChange={(e)=>setText(e.target.value)}
          onKeyDown={(e)=>{ if(e.key==='Enter' && text.trim()){ addGoal(text.trim()); setText(''); } }}
        />
        <button
          className="px-3 py-2 rounded-lg bg-slate-900 text-white"
          onClick={()=>{ if(text.trim()){ addGoal(text.trim()); setText(''); } }}
        >Add</button>
      </div>
      <ul className="space-y-2">
        {goals.map((g, i)=>(
          <li key={i} className="flex items-center justify-between bg-white/70 rounded-xl p-2 shadow">
            <span>{g}</span>
            <button className="text-sm text-red-600" onClick={()=>removeGoal(i)}>remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
