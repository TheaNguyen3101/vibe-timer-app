'use client';
import { useEffect, useRef, useState } from 'react';
import NotesModal from './NotesModal';

export default function Timer({ onSessionEnd, sessions }) {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const [mode, setMode] = useState('focus'); // focus | break
  const [showModal, setShowModal] = useState(false);
  const intervalRef = useRef(null);

  useEffect(()=>{
    if (!running) return;
    intervalRef.current = setInterval(()=>{
      setSeconds(prev => {
        if (prev === 0) {
          if (minutes === 0) {
            // session end
            clearInterval(intervalRef.current);
            setRunning(false);
            if (mode === 'focus') {
              setShowModal(true);
            }
            const endedMode = mode;
            // switch mode
            const nextMode = endedMode === 'focus' ? 'break' : 'focus';
            setMode(nextMode);
            setMinutes(nextMode === 'focus' ? 25 : 5);
            setSeconds(0);
            onSessionEnd(endedMode);
            return 0;
          } else {
            setMinutes(m => m - 1);
            return 59;
          }
        } else {
          return prev - 1;
        }
      });
    }, 1000);
    return ()=> clearInterval(intervalRef.current);
  }, [running, minutes, mode, onSessionEnd]);

  const toggle = ()=> setRunning(r => !r);
  const reset = ()=> {
    setRunning(false);
    setMode('focus');
    setMinutes(25);
    setSeconds(0);
  };

  const onSaveNote = (text) => {
    setShowModal(false);
    // pass note up handled by parent via onSessionEnd->... but here we trigger separately
    // parent will show modal, so we just close here.
  };

  const total = (mode === 'focus' ? 25 : 5) * 60;
  const remaining = minutes * 60 + seconds;
  const progress = 1 - remaining / total;

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Pomodoro Timer</h2>
      <div className="mx-auto w-48 h-48 rounded-full bg-white/70 shadow grid place-items-center relative overflow-hidden">
        <div
          className="absolute inset-0 bg-slate-900/10"
          style={{ clipPath: `inset(${(1-progress)*100}% 0 0 0)` }}
        />
        <div className="text-center">
          <div className="text-sm uppercase tracking-wide text-slate-600">{mode === 'focus' ? 'Focus' : 'Break'}</div>
          <div className="text-4xl font-bold tabular-nums">{String(minutes).padStart(2,'0')}:{String(seconds).padStart(2,'0')}</div>
        </div>
      </div>
      <div className="flex gap-2 justify-center">
        <button className="px-3 py-2 rounded-lg bg-slate-900 text-white" onClick={toggle}>{running ? 'Pause' : 'Start'}</button>
        <button className="px-3 py-2 rounded-lg border" onClick={reset}>Reset</button>
        <button className="px-3 py-2 rounded-lg border" onClick={()=>{ setMode(m=> m==='focus'?'break':'focus'); setMinutes(m=> m==='focus'?5:25); setSeconds(0); }}>Switch</button>
      </div>
      <NotesModal open={showModal} onClose={()=>setShowModal(false)} onSave={onSaveNote} />
    </div>
  );
}
