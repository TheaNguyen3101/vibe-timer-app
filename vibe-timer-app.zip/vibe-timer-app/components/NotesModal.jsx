'use client';
import { useState } from 'react';

export default function NotesModal({ open, onClose, onSave }) {
  const [text, setText] = useState('');
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-4 w-full max-w-md shadow-xl">
        <h3 className="text-lg font-semibold mb-2">What have you done so far?</h3>
        <textarea
          className="w-full border rounded-lg p-2 min-h-[120px]"
          placeholder="Type a short note…"
          value={text}
          onChange={(e)=>setText(e.target.value)}
        />
        <div className="mt-4 flex gap-2 justify-end">
          <button className="px-3 py-2 rounded-lg border" onClick={onClose}>Cancel</button>
          <button
            className="px-3 py-2 rounded-lg bg-slate-900 text-white"
            onClick={()=>{ onSave(text); setText(''); }}
          >Save</button>
        </div>
      </div>
    </div>
  );
}
